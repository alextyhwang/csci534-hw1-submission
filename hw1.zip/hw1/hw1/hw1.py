#!/usr/bin/python3

import math

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry

class HW0(Node):
    def __init__(self):
        super().__init__('hw1')

        self.FORWARD='forward'
        self.TURNING='turning'
        self.DONE='done'
        self.state=self.FORWARD
        self.start_x=None
        self.start_y=None
        self.turn_start_time=None

        self.publisher=self.create_publisher(Twist,'/RosAria/cmd_vel',10)
        self.subscription=self.create_subscription(
            Odometry,'/RosAria/odom',self.odom_callback,10
        )
    # callback function
    def odom_callback(self,msg):
        x=msg.pose.pose.position.x
        y=msg.pose.pose.position.y

        if self.start_x==None:
            self.start_x=x
            self.start_y=y

        distance=math.hypot(x-self.start_x,y-self.start_y)
        command=Twist()

        if self.state==self.FORWARD:
            if distance<2.0:
                command.linear.x=0.3
            else:
                self.state=self.TURNING
                self.turn_start_time=self.get_clock().now()

        if self.state==self.TURNING:
            elapsed=(self.get_clock().now()-self.turn_start_time).nanoseconds/1e9
            if elapsed<3.0:
                command.angular.z=0.5
            else:
                self.state=self.DONE

        self.get_logger().info(f'Position X: {x}')
        self.get_logger().info(f'Position Y: {y} ')
        self.publisher.publish(command)

def main(args=None):
    rclpy.init(args=args)
    node = HW0()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
